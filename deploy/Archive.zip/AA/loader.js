(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.PTLogoSigilsSmall = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(2,1,1).p("AAAiZIAAAfQAzAAAkAkIAAAAIhXBWIBXBXQgkAlgzAAQgyAAgkgkIgWAVAB7AAIAfAAABXhWQAkAkAAAyQAAAzgkAkIAWAWAAAAAIB7AAAAAAAIAAB8IAAAeAAAh6IAAB6ABthsIgWAWAiZAAIAfAAQAAgyAkgkIBWBWAhWBYIAAgBQgkgkAAgzIB6AAgAhshsIAWAWQAkgkAyAA");
	this.shape.setTransform(0.025,-39.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(2,1,1).p("AAAgyQACAAACACQABAAAAACQAAABAAAAQAAACgBACIAAAAQgCABgCAAQgBAAgCgBIAAAAQgBgCAAgCQAAAAAAgBQABgCAAAAQACgCABAAIAAAHIAFgDAAAgrIAAADAAAgrIAEACAiZiFIEzAAIiaELgAgDgpIADgCAgEguIAEAD");
	this.shape_1.setTransform(0.025,-34.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(2,1,1).p("AAAiyIAAAzACzAAIgzAAAg+AAQALANAPAQQADADACAFQATASANAcQANgcASgSQADgFADgDQAPgQALgNQAOgSgCgWQgBgKgDgGQgFgLgKgFQgIgEgLACQgJABgJAGQgJAEgHAHQgCABgBADQgBgDgCgBQgHgHgJgEQgJgGgJgBQgKgCgJAEQgKAFgFALQgDAGAAAKQgDAWAOASgAAACzIAAgzAiyAAIAzAA");
	this.shape_2.setTransform(0.025,-39.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(2,1,1).p("AAAiZIAAAzAAACaIAAgzACaAAIgzAAABtBtIgkgkAA0AAQAAAWgPAPQgPAPgWAAQgUAAgPgPQgPgPAAgWQAAgUAPgPQAPgPAUAAQAWAAAPAPQAPAPAAAUgABthsIgkAkAiZAAIAzAAAhsBtIAkgkAhshsIAkAk");
	this.shape_3.setTransform(0.025,-39.575);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(2,1,1).p("AiZALQgDgIABgIQACgPAKgKQAUgTAcALQgGgMABgMQAAgSAPgJQAPgKAQAJQAOAFADAKQADguAigDQAjADADAuQADgKANgFQARgJAPAKQAOAJABASQAAAMgFAMQAbgLAUATQALAKACAPQAAAIgCAIQgEAMgJAGQgEAEgKACIj9AAQgKgCgEgEQgKgGgDgMgAAABJIAAA0AA+BJIAAA0Ag+BJIAAA0");
	this.shape_4.setTransform(0.0649,-38.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FFFFFF").ss(2,1,1).p("AAzhLQAAAVgPAPQgPAPgVAAQgVAAgPgPQgPgPAAgVQAAgWAPgPQAPgPAVAAQAVAAAPAPQAPAPAAAWgAiaCAQAGAAAGgFQACgCAEgFQAEgFAGgLQADgGAFgJQAUgnAkAGQgGAEgFAGQgKAMAAAOQAAAMAHAMQAKAPAPABQAHAAAFgFQADgCADgFQAEgFAHgLQADgGAEgJQATgnAlAGQgGAEgGAGQgJAMAAAOQAAAMAGAMQAKAPAQABQAGAAAGgFQACgCAEgFQAFgFAFgLQADgGAEgJQAVgnAlAGQgHAEgFAGQgKAMAAAOQAAAMAIAMQAJAPAPAB");
	this.shape_5.setTransform(0.05,-41.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(2,1,1).p("AAtiTQAUAGARALABDCMQgNAGgNADACSAyQgFAQgJAPACLhBQAHANADAOAhJiHQAPgIASgFAgvCTQgQgFgPgIAiIBJQgIgOgEgRAiTgsQAEgQAJgO");
	this.shape_6.setTransform(0.075,-39.5875);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(2,1,1).p("AhEAnIBEg+IAAhvIBFBAAAACHIAAieIBFA+AhEhGIBEhA");
	this.shape_7.setTransform(0.025,-39.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(2,1,1).p("AAAgEQACAAABABQABABABABQAAABAAAAQAAACgCABIAAABQgBABgCAAQgBAAgCgBIAAgBQgCgBAAgCQAAAAABgBQAAgBABgBQACgBABAAIAAAFIAFgCAAAABIADACAAAABIAAAEAhLiDICXAAIBMCDIhMCDIiXABIhMiEgAgDADIADgCAgEgBIAEAC");
	this.shape_8.setTransform(0.05,-39.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).wait(1));

	// Layer_2
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FFFFFF").ss(2,1,1).p("AGQAAIGQmPIAAmQAGQAAIAAsfIsfAAIAAGQImQmQAmPAAIAAMgAmPAAImQAAAmPAAImQmPAmPmPIAAGPIMfAA");

	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(9));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81,-81,162,162);


(lib.PTLogoSigils = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(4,1,1).p("AABpoIAAB8QDMAACQCQIABABQCQCQAADLIB7AAAABAAIHtAAQAADNiRCQQiQCRjMAAIAAB7AABnsIAAHsIAAHuQjMAAiQiQIgCgBQiPiQAAjNIHtAAIFcFdIBYBYAFelbIldFbIlcFeIhYBXAG1m0IhXBZApoAAIB8AAQAAjLCPiRQCSiQDMAAAmzm0IBWBYIFeFc");
	this.shape.setTransform(0.1,-118.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(4,1,1).p("AABjLIAAAbIATgMQABAEAAACQAAAIgFAGIAAABQgGAFgJAAQgHAAgHgFIAAgBQgGgGAAgIQAAgCABgEQADgGACgCQAHgHAHAAQAJAAAGAHQACACACAGAABiwIAAAOAABiwIAPAIApooVITRAAIpoQsgAgNioIAOgIAgSi8IATAM");
	this.shape_1.setTransform(0.1,-99.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(4,1,1).p("AABpoIAADNAiogEQAeAnAnAqQAIAIAIAKQAxA0AjBKQAjhKAxg0QAJgKAHgIQAngqAegnQAkgwgFg8QgCgYgHgQQgNgcgcgQQgXgLgbAGQgYADgZAQQgXALgRATQgHAEgEAHQgEgHgFgEQgTgTgWgLQgagQgYgDQgbgGgWALQgdAQgMAcQgIAQgBAYQgGA8AkAwgAJpAAIjNAAAABJpIAAjNApoAAIDOAA");
	this.shape_2.setTransform(0.1,-118.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(4,1,1).p("AABpoIAADNADOAAQAABWg8A8Qg7A8hWAAQhVAAg9g8Qg7g8AAhWQAAhUA7g9QA9g8BVAAQBWAAA7A8QA8A9AABUgAJpAAIjNAAAG1m0IiRCSAABJpIAAjNAG1G1IiRiRApoAAIDOAAAmzm0ICRCSAmzG1ICRiR");
	this.shape_3.setTransform(0.1,-118.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(4,1,1).p("ApoAvQgKgjAEglQAHg5ApgnQBQhLBwAqQgXgwACgwQAChIA6gkQA9gnBBAgQA3AZALAlQANi3CKgLQCLALAMC3QAMglA3gZQBCggA7AnQA6AkACBIQACAwgVAwQBugqBQBLQApAnAIA5QADAlgKAjQgPAugmAZQgQAMgnAMIv3AAQgngMgRgMQgmgZgPgugAD6EiIAADQAAAEiIAADQAj8EiIAADQ");
	this.shape_4.setTransform(0.2013,-113.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FFFFFF").ss(4,1,1).p("ADNkwQAABWg8A8Qg7A8hWAAQhVAAg9g8Qg7g8AAhWQAAhVA7g9QA9g8BVAAQBWAAA7A8QA8A9AABVgApsH/QAaAAAWgTQAKgIAQgUQASgVAVgtQAOgZARgjQBQidCUAbQgbAPgUAZQgnAtAAA8QAAAtAeAwQAkA8A+AFQAbAAAWgTQALgIAOgUQAQgVAYgtQANgZAPgjQBRidCTAbQgZAPgVAZQgnAtAAA8QAAAtAcAwQAnA8A/AFQAYAAAXgTQAJgIAQgUQATgVAVgtQAMgZAQgjQBSidCSAbQgZAPgUAZQgnAtAAA8QAAAtAdAwQAlA8A+AF");
	this.shape_5.setTransform(0.175,-125.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgVJ3QgGgGAAgIQAAgIAGgGQAGgGAIAAQB6gBBogtQAIgEAIAEQAHACADAIQAEAIgDAIQgDAHgIADQhvAwiDACIAAAAQgIAAgGgGgAm6HUQgIAAgGgGIgLgLQhWhVguhmQgDgIACgIQADgHAIgEQAIgDAHADQAIADADAHQAsBfBQBRIALALQAGAGAAAIQAAAIgGAGQgFAGgJAAIAAAAgAIkD9QgIgDgDgIQgDgHADgIQAqhpAAh5QAAgIAGgGQAGgGAIAAQAJAAAFAGQAGAGAAAIQAACCgtBvQgDAIgIADQgEACgEAAQgDAAgEgCgAJIgbQgGgGAAgIQgIh5gzhnQgDgHACgIQADgIAHgDQAIgEAHACQAIADAEAHQA3BuAICCQAAAIgFAGQgGAGgIABIgBAAQgIAAgGgFgApdjAQgIgDgDgHQgEgHADgIQAphzBXhfQAGgGAIgBQAIAAAGAGQAGAFABAJQAAAIgGAGQhRBZgnBrQgCAIgIADQgEACgEAAIgHgBgACyo1QhbgfhnAAIghABQgIAAgHgFQgGgGAAgIQgBgIAGgGQAFgGAIgBIAkgBQBuAABhAhQAIADADAHQAEAIgDAHQgDAIgHAEQgEACgFAAIgGgBg");
	this.shape_6.setTransform(1.8759,-118.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(4,1,1).p("AkUCeIEQj8IAAm8IEZD/AkUkbIEQj/AgEIcIAAp6IEZD8");
	this.shape_7.setTransform(0.1,-117.65);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(4,1,1).p("AAAgTIAAAaIAUgLQABADAAABQAAAIgGAGIAAABQgGAFgJAAQgGAAgIgFIAAgBQgGgGAAgIQAAgBACgDQACgHACgBQAIgHAGAAQAJAAAGAHQADABACAHAAAAHIAAANAAAAHIAPAHAkvoPIJfAAIEwIPIkwINIpfADIkwoQgAgOAOIAOgHAgSgEIASAL");
	this.shape_8.setTransform(0.125,-118.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).wait(1));

	// Layer_2
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FFFFFF").ss(4,1,1).p("AZAAAIZA4/IAA5AAZAAAMAAAgx/Mgx/AAAIAAZAI5A5AA4/AAI5AAAA4/AAMAAAAyAA4/4/IAAY/I5A4/A4/AAMAx/AAA");
	this.shape_9.setTransform(0.025,40.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(9));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-321.9,-281.9,643.9,643.9);


// stage content:
(lib.loader = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.PTLogoSigilsSmall();
	this.instance.setTransform(804.2,764.2,1,1,0,0,0,0,40);

	this.instance_1 = new lib.PTLogoSigils();
	this.instance_1.setTransform(512.1,514.15,1,1,0,0,0,0,40);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(702.2,704.2,183,132);
// library properties:
lib.properties = {
	id: '6E551C23227A4C0691433EE6D5852D40',
	width: 1024,
	height: 1024,
	fps: 30,
	color: "#666666",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['6E551C23227A4C0691433EE6D5852D40'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;